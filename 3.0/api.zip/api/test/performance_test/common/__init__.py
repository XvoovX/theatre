#!/usr/bin/env python
# -*- coding:utf-8 -*-

<<<<<<< HEAD:12-flask-api-project-test/app/test/performance_test/common/__init__.py
# file:__init__.py.py
# author:jackiex
# datetime:2022/9/28 18:10
# software: PyCharm

'''
    this is function  description 
'''
# import module your need
=======
# file:__init__.py
# author:Nathan
# datetime:2022/4/20 23:22
# software: PyCharm

"""
    this is function description
"""
>>>>>>> 38d21d727f2cb6e23af283e79e504b47de7c19fe:12-flask-api-project-test/app/performance_test/common/__init__.py
